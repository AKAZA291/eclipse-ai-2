ECLIPSE AI SOCIAL — PROJETO INICIAL

COMO ABRIR
1. Extraia o ZIP.
2. Abra index.html em um navegador atualizado.
3. Gere roteiros e legendas variados.
4. Edite os campos entre colchetes e confira os fatos.
5. Selecione um vídeo pronto para pré-visualizar e adicionar à fila.
6. Aprove manualmente e publique pelo TikTok.

RECURSOS
- Painel responsivo.
- Gerador de modelos de roteiro e legenda.
- Sugestões de temas variados.
- Pré-visualização de vídeo local.
- Fila com estados: aguardando aprovação, aprovado e marcado como publicado.

LIMITAÇÕES IMPORTANTES
- O gerador atual usa modelos locais, não um modelo de IA remoto.
- Não cria/renderiza o vídeo automaticamente.
- Não publica no TikTok nem se conecta à conta.
- A fila não é persistente: ao fechar ou recarregar a página, os rascunhos somem.
- Para geração real com IA, conecte uma API por backend e guarde a chave somente no servidor.
- Para publicação integrada, use a documentação oficial TikTok for Developers / Content Posting API. É necessário app, OAuth, permissões e aprovação aplicável. Não use automação de login por senha nem compartilhe tokens.
